mkdir output
gdown 1-UhHASIrnGQ5YRJmQwrEFpakG3dLcYXr -O ckpt/intent/best.pt 
gdown 10Cwtbolt6FBoVXS4OFZvx8WHpSr-WWB0 -O ckpt/slot/best.pt